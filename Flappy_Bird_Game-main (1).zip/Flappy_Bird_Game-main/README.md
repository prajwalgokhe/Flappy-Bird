# Flappy_Bird_Game
Hey everyone, This is a simple game which will just take you to a nostalgic trip when we all used to play this game(or similar one) in keypad phones.
